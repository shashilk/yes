# web-python2.7-simple

Python 2.7 Sample Application

# Developer Workspace
[![Contribute](http://beta.codenvy.com/factory/resources/codenvy-contribute.svg)](http://beta.codenvy.com/f?id=c9gjtuvo566cyuxt)

# Stack to use

FROM [codenvy/ubuntu_python:2.7](https://hub.docker.com/r/codenvy/ubuntu_python/)

# How to run

| #       | Description           | Command  |
| :------------- |:-------------| :-----|
| 1      | Run | `cd ${current.project.path} && sudo virtualenv /env && sudo pip install -r requirements.txt && python main.py` |